/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jobber;

import jobber.gui.Frm_Login;



//comentario
//comentario do guihgo
/**
 *
 * @author rfutenma
 */

public class Main {
    public static void main(String args[]) {
        System.out.println("Estamos rodando !");
        Frm_Login l = new Frm_Login();
        l.setVisible(true);
    }
}
