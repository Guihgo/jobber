package jobber.modelo;

public class Mensagem {

	private String msg;
	private int idAutor;

	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getMsg() {
		return this.msg;
	}

	public void setIdAutor(int idAutor) {
		this.idAutor = idAutor;
	}
	public int getIdAuotr() {
		return this.idAutor;
	}

}
