package jobber;

public class Cliente extends Conta{

	private Processo processos[];
	
	
	//METODODS
	//busca trabalho
	//cria processo
	//confirmaAvalia processo 
}
